public class Main {
    public static void main(String[] args) {
        BinaryTree bt = new BinaryTree();
        bt.add(4);
        bt.add(2);
        bt.add(1);
        bt.add(3);
        bt.add(5);
        bt.add(6);
        bt.printTree();
        System.out.println(bt.containsNode(6));
        System.out.println(bt.containsNode(7));
        System.out.println();
        bt.remove(6);
        System.out.println(bt.containsNode(6));
        System.out.println(bt.containsNode(7));
    }
}
